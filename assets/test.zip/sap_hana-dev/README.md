#  SAP HANA
Коннектор SAP HANA предназначен для сбора внутренних событий информационной безопасности, относящихся к СУБД SAP HANA  
## Сбор событий
- модуль сбора -  **Syslog**
- SAP HANA отправляет события через syslog и сохраняет события в текстовый файл
## Информация о ПО
- Поддерживаемые версии: SAP HANA 2.00.040.00.1553674765
- Вендор: Sap
## Информация о событиях
- Количество событий: **110** уникальных событий  
- Источник событий для разработки: Часть событий взяты из отчетов, которые хранятся в папке **\\srvhdfs00.gis.lan\DFS01\DSI-OSM-GISOKiA-Distrib\Event Sources\5_СУБД\SAP\SAP HANA** и часть сгенерирована на стенде 
## Стенд
- SAP HANA Studio установлена на 10.10.58.58 (WINDOWS SERVER 2019), запуск через ярлык в панели "Пуск"  
Для доступа к ОС:  
SAP\NEPOCHATOV  
Init1234
- Сама база данных развернута на стенде 10.10.58.35  
User Name:  SYSTEM  
Password:   Init1234
- Ответственный за стенд Цыбденов Тимур Евгеньевич (Tsybdenov-T@gaz-is.ru) 
## Контакты
- Куратор: Непочатов Александр (nepochatov-a@datagile.ru)  
- Разработчик: Демаков Ярослав (demakov-y@datagile.ru)  

# !!!Выполнена проверка коннектора аналитиком и разработан контент.
При внесении следующих изменений в коннектор необходимо согласование с **[Ауловой Ксенией](http://10.10.26.36/gitlab/Aulova-K)**:
- изменение состава событий (событие добавлено/удалено)
- изменение маппинга
- изменение ID
- изменение категоризации
- изменение типа сбора

## === СВОДНАЯ ИНФОРМАЦИЯ ===
| Параметр| Значение |
|---------|----------|
| class | СУБД |
| product | HANA |
| vendor | SAP |
| version | 2.00.040.00.1553674765 |
| env | Linux |
| protocol | UDP/TCP |
| module | Syslog |
| standart | false |
| siem_ver | 4.1 Agent by Lin, 4.1 Agent by Win, 5.1 Agent by Lin, 5.1 Agent by Win |
| norm_level | экспертное |
| corr_level |  |
| events_count | 110 |
| comm_corr_count | 11 |
| infr_corr_count | 48 |
| scada_corr_count |  |
| src_corr_count |  |
| cert |  |
| source | документ, стенд, выгрузка с объекта |
| rnd_pl_level |  |
| rnd_pl_norm |  |
| unsupported_versions |  |
| comments |  |
| event_types | События ИБ, Функциональные события |
| approved | false  |
| siem_vendor | sap |
| siem_product | hana |  
| release_date |  |
